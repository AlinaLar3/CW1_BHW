﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Реализация репозитория, хранящего данные в памяти.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class InMemoryRepository<T> : IRepository<T> where T : class
    {
        private readonly List<T> _data = new List<T>();

        public T Get(Guid id)
        {
            var propertyInfo = typeof(T).GetProperty("Id");
            if (propertyInfo == null)
            {
                throw new InvalidOperationException("Тип T должен иметь свойство 'Id'.");
            }

            return _data.FirstOrDefault(item => propertyInfo.GetValue(item).Equals(id));
        }

        public List<T> GetAll()
        {
            return _data;
        }

        public void Add(T entity)
        {
            _data.Add(entity);
        }

        public void Update(T entity)
        {
            var propertyInfo = typeof(T).GetProperty("Id");
            if (propertyInfo == null)
            {
                throw new InvalidOperationException("Тип T должен иметь свойство 'Id'.");
            }

            var id = propertyInfo.GetValue(entity);
            var existingEntity = _data.FirstOrDefault(item => propertyInfo.GetValue(item).Equals(id));
            if (existingEntity != null)
            {
                _data.Remove(existingEntity);
                _data.Add(entity);
            }
            else
            {
                throw new ArgumentException("Объект не найден.");
            }
        }

        public void Delete(Guid id)
        {
            var propertyInfo = typeof(T).GetProperty("Id");
            if (propertyInfo == null)
            {
                throw new InvalidOperationException("Тип T должен иметь свойство 'Id'.");
            }

            var entityToRemove = _data.FirstOrDefault(item => propertyInfo.GetValue(item).Equals(id));
            if (entityToRemove != null)
            {
                _data.Remove(entityToRemove);
            }
        }
    }
}
