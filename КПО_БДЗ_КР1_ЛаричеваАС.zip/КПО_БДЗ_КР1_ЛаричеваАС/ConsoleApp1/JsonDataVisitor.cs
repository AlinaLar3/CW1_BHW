﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Посетитель для экспорта данных в JSON-файл.
    /// </summary>
    public class JsonDataVisitor : IDataVisitor
    {
        private string _filePath;

        public JsonDataVisitor(string filePath)
        {
            _filePath = filePath;
        }

        public void Visit(FinancialData data)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(new
            {
                BankAccounts = data.BankAccounts,
                Categories = data.Categories,
                Operations = data.Operations
            }, options);
            File.WriteAllText(_filePath, json);
            Console.WriteLine($"Data exported to JSON: {_filePath}");
        }
    }
}
