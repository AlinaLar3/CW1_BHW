﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Интерфейс для сервиса управления банковскими счетами.
    /// </summary>
    public interface IBankAccountService
    {
        BankAccount CreateAccount(string name, int initialBalance);
        BankAccount CreateAccount(BankAccount bankAccount);
        BankAccount GetAccount(Guid id);
        void UpdateAccount(BankAccount account);
        void DeleteAccount(Guid id);
        List<BankAccount> GetAllAccounts();
    }

}
