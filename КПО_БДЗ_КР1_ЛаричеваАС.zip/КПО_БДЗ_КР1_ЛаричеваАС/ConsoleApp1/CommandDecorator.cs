﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Абстрактный класс для декоратора команд.
    /// </summary>
    public abstract class CommandDecorator : ICommand
    {
        private readonly ICommand _command;

        protected CommandDecorator(ICommand command)
        {
            _command = command;
        }

        public virtual void Execute()
        {
            _command.Execute();
        }
    }
}
