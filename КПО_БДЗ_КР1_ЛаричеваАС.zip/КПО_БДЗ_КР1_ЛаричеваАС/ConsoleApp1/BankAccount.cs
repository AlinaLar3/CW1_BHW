﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Банковский счёт.
    /// </summary>
    public class BankAccount
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int Balance { get; set; }
        public BankAccount() { }

        public BankAccount(string name, int initialBalance)
        {
            Id = Guid.NewGuid();
            Name = name;
            Balance = initialBalance;
        }
        public BankAccount(Guid id, string name, int initialBalance)
        {
            Id = id;
            Name = name;
            Balance = initialBalance;
        }
    }
}
