﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Абстрактный класс для импорта данных.
    /// </summary>
    public abstract class DataImporter
    {
        public void ImportData(string filePath, IBankAccountService bankAccountService, ICategoryService categoryService, IOperationService operationService)
        {
            try
            {
                Console.WriteLine($"Начало импорта из {filePath}");
                string data = ReadData(filePath);
                FinancialData operations = ParseData(data);
                SaveData(operations, bankAccountService, categoryService, operationService);
                Console.WriteLine($"Импорт из {filePath} завершён успешно.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error during import: {ex.Message}");
            }
        }

        protected abstract string ReadData(string filePath);
        protected abstract FinancialData ParseData(string data);

        private void SaveData(FinancialData financialData, IBankAccountService bankAccountService, ICategoryService categoryService, IOperationService operationService)
        {
            Console.WriteLine("Saving data:");

            Console.WriteLine("Accounts:");
            foreach (var account in financialData.BankAccounts)
            {
                bankAccountService.CreateAccount(account);
                Console.WriteLine($" - {account.Name}: {account.Balance}");
            }

            Console.WriteLine("Categories:");
            foreach (var category in financialData.Categories)
            {
                categoryService.CreateCategory(category);
                Console.WriteLine($" - {category.Name} ({category.Type})");
            }

            Console.WriteLine("Operations:");
            foreach (var operation in financialData.Operations)
            {
                operationService.CreateOperation(operation);
                Console.WriteLine($" - {operation.Type}: {operation.Amount} on {operation.Date}");
            }
        }
    }
}
