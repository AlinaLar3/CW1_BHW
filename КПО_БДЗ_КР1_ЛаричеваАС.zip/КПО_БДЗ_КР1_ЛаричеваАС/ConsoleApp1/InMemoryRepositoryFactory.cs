﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Реализация фабрики репозиториев.
    /// </summary>
    public class InMemoryRepositoryFactory : IRepositoryFactory
    {
        public IRepository<T> CreateRepository<T>() where T : class
        {
            return new InMemoryRepository<T>();
        }
    }
}
