﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Финансовая операция.
    /// </summary>
    public class Operation
    {
        public Guid Id { get; set; }
        public CategoryType Type { get; set; }
        public Guid BankAccountId { get; set; }
        public int Amount { get; set; }
        public DateTime Date { get; set; }
        public string Description { get; set; }
        public Guid CategoryId { get; set; }

        public Operation() { }
        public Operation(CategoryType type, Guid bankAccountId, int amount, DateTime date, Guid categoryId, string description = null)
        {
            Id = Guid.NewGuid();
            Type = type;
            BankAccountId = bankAccountId;
            Amount = amount;
            Date = date;
            Description = description;
            CategoryId = categoryId;
        }
        public Operation(Guid operationid, CategoryType type, Guid bankAccountId, int amount, DateTime date, Guid categoryId, string description = null)
        {
            Id = operationid;
            Type = type;
            BankAccountId = bankAccountId;
            Amount = amount;
            Date = date;
            Description = description;
            CategoryId = categoryId;
        }
    }
}
