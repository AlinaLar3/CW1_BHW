﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Импорт из CSV.
    /// </summary>
    public class CsvDataImporter : DataImporter
    {
        protected override string ReadData(string filePath)
        {
            return File.ReadAllText(filePath);
        }

        protected override FinancialData ParseData(string data)
        {
            List<BankAccount> accounts = new List<BankAccount>();
            List<Category> categories = new List<Category>();
            List<Operation> operations = new List<Operation>();

            string[] lines = data.Split(Environment.NewLine);

            for (int i = 0; i < lines.Length; i++)
            {
                string[] values = lines[i].Split(',');
                if (values.Length < 1) continue;
                switch (values[0].Trim().ToLower())
                {
                    case "account":
                        if (values.Length == 4)
                        {
                            try
                            {
                                Guid bankAccountId = Guid.Parse(values[1]);
                                string name = values[2];
                                int initialBalance = int.Parse(values[3]);
                                BankAccount account = new BankAccount(bankAccountId, name, initialBalance);
                                if (!accounts.Contains(account))
                                {
                                    accounts.Add(account);
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Ошибка парсинга {i + 1}: {ex.Message}");
                            }
                        }
                        break;

                    case "category":
                        if (values.Length == 4)
                        {
                            try
                            {
                                Guid categoryId = Guid.Parse(values[1]);
                                CategoryType type = (CategoryType)Enum.Parse(typeof(CategoryType), values[2]);
                                string name = values[3];
                                Category category = new Category(categoryId, type, name);
                                if (!categories.Contains(category))
                                {
                                    categories.Add(category);
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Ошибка парсинга {i + 1}: {ex.Message}");
                            }
                        }
                        break;

                    case "operation":
                        if (values.Length == 8)
                        {
                            try
                            {
                                CategoryType type = (CategoryType)Enum.Parse(typeof(CategoryType), values[2]);
                                Guid bankAccountId = Guid.Parse(values[3]);
                                int amount = int.Parse(values[4]);
                                DateTime date = DateTime.Parse(values[5]);
                                Guid categoryId = Guid.Parse(values[7]);
                                string description = values[6];
                                Guid operationId = Guid.Parse(values[1]);
                                Operation operation = new Operation(type, bankAccountId, amount, date, categoryId, description);
                                if (!operations.Contains(operation))
                                {
                                    operations.Add(operation);
                                }
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Ошибка парсинга {i + 1}: {ex.Message}");
                            }
                        }
                        break;

                    default:
                        Console.WriteLine($"Неизвестный тип {i + 1}: {values[0]}");
                        break;
                }
            }

            return new FinancialData(accounts, categories, operations);
        }
    }
}

