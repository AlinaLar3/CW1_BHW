﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Интерфейс для сервиса управления операциями.
    /// </summary>
    public interface IOperationService
    {
        Operation CreateOperation(CategoryType type, Guid bankAccountId, int amount, DateTime date, Guid categoryId, string description = null);
        Operation CreateOperation(Operation operation);
       Operation GetOperation(Guid id);
        void UpdateOperation(Operation operation);
        void DeleteOperation(Guid id);
        List<Operation> GetAllOperations();
        List<Operation> GetOperationsByAccount(Guid accountId);

    }

}
