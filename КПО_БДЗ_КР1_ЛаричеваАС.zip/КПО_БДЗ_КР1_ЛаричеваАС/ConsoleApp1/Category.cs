﻿using CW1_LarichevaAS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Категория.
    /// </summary>
    
    public class Category
    {
        public Guid Id { get; set; }
        public CategoryType Type { get; set; }
        public string Name { get; set; }

        public Category() {}
        public Category(CategoryType type, string name)
        {
            Id = Guid.NewGuid();
            Type = type;
            Name = name;
        }
        public Category(Guid id, CategoryType type, string name)
        {
            Id = id;
            Type = type;
            Name = name;
        }
    }
}
