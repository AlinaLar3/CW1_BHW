﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Реализация интерфейса для сервиса управления банковскими счетами.
    /// </summary>
    public class BankAccountService : IBankAccountService
    {
        private readonly IRepository<BankAccount> _accountRepository;

        public BankAccountService(IRepository<BankAccount> accountRepository)
        {
            _accountRepository = accountRepository;
        }

        public BankAccount CreateAccount(string name, int initialBalance)
        {
            var account = new BankAccount(name, initialBalance);
            _accountRepository.Add(account);
            return account;
        }
        public BankAccount CreateAccount(BankAccount bankaccount)
        {
            _accountRepository.Add(bankaccount);
            return bankaccount;
        }

        public BankAccount GetAccount(Guid id)
        {
            return _accountRepository.Get(id);
        }

        public void UpdateAccount(BankAccount account)
        {
            _accountRepository.Update(account);
        }

        public void DeleteAccount(Guid id)
        {
            _accountRepository.Delete(id);
        }

        public List<BankAccount> GetAllAccounts()
        {
            return _accountRepository.GetAll();
        }
    }
}
