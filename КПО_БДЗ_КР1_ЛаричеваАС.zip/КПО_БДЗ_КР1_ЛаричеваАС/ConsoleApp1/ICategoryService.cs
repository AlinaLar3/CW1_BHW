﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Интерфейс для сервиса управления категориями.
    /// </summary>
    public interface ICategoryService
    {
        Category CreateCategory(CategoryType type, string name);
        Category CreateCategory(Category category);
        Category GetCategory(Guid id);
        void UpdateCategory(Category category);
        void DeleteCategory(Guid id);
        List<Category> GetAllCategories();
    }

}
