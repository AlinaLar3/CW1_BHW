﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Реализация интерфейса для сервиса управления финансовыми операциями.
    /// </summary>
    public class OperationService : IOperationService
    {
        private readonly IRepository<Operation> _operationRepository;
        private readonly IBankAccountService _bankAccountService;

        public OperationService(IRepository<Operation> operationRepository, IBankAccountService bankAccountService)
        {
            _operationRepository = operationRepository;
            _bankAccountService = bankAccountService;
        }

        public Operation CreateOperation(CategoryType type, Guid bankAccountId, int amount, DateTime date, Guid categoryId, string description = null)
        {
            var account = _bankAccountService.GetAccount(bankAccountId);
            if (account == null)
            {
                throw new ArgumentException("Неправильный BankAccountId");
            }

            var operation = new Operation(type, bankAccountId, amount, date, categoryId, description);
            _operationRepository.Add(operation);

            if (type == CategoryType.Income)
            {
                account.Balance += amount;
            }
            else
            {
                account.Balance -= amount;
            }
            _bankAccountService.UpdateAccount(account);

            return operation;
        }
        public Operation CreateOperation(Operation operation)
        {
            _operationRepository.Add(operation);
            return operation;
        }

        public Operation GetOperation(Guid id)
        {
            return _operationRepository.Get(id);
        }

        public void UpdateOperation(Operation operation)
        {
            _operationRepository.Update(operation);
        }

        public void DeleteOperation(Guid id)
        {
            _operationRepository.Delete(id);
        }

        public List<Operation> GetAllOperations()
        {
            return _operationRepository.GetAll();
        }

        public List<Operation> GetOperationsByAccount(Guid accountId)
        {
            return _operationRepository.GetAll().Where(o => o.BankAccountId == accountId).ToList();
        }
    }
}
