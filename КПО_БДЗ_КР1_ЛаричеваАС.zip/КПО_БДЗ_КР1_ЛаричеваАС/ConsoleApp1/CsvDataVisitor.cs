﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Посетитель для экспорта данных в CSV.
    /// </summary>
    public class CsvDataVisitor : IDataVisitor
    {
        private string _filePath;

        public CsvDataVisitor(string filePath)
        {
            _filePath = filePath;
        }

        public void Visit(FinancialData data)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(_filePath))
                {
                    foreach (var operation in data.Operations)
                    {
                        writer.WriteLine($"operation,{operation.Id},{operation.Type},{operation.BankAccountId},{operation.Amount},{operation.Date},{operation.Description},{operation.CategoryId}");
                    }
                    foreach (var account in data.BankAccounts)
                    {
                        writer.WriteLine($"account,{account.Id},{account.Name},{account.Balance}");
                    }
                    foreach (var category in data.Categories)
                    {
                        writer.WriteLine($"category,{category.Id},{category.Type},{category.Name}");
                    }
                }

                Console.WriteLine($"Данные экспортированы в CSV: {_filePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка экспорта в CSV: {ex.Message}");
            }
        }
    }
}
