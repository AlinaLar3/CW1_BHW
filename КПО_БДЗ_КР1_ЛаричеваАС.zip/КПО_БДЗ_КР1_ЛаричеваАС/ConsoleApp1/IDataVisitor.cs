﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Интерфейс для посетителя.
    /// </summary>
    public interface IDataVisitor
    {
        void Visit(FinancialData data);
    }
}
