﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Реализация интерфейса для сервиса управления категориями.
    /// </summary>
    public class CategoryService : ICategoryService
    {
        private readonly IRepository<Category> _categoryRepository;

        public CategoryService(IRepository<Category> categoryRepository)
        {
            _categoryRepository = categoryRepository;
        }

        public Category CreateCategory(CategoryType type, string name)
        {
            var category = new Category(type, name);
            _categoryRepository.Add(category);
            return category;
        }
        public Category CreateCategory(Category category)
        {
            _categoryRepository.Add(category);
            return category;
        }
        public Category GetCategory(Guid id)
        {
            return _categoryRepository.Get(id);
        }

        public void UpdateCategory(Category category)
        {
            _categoryRepository.Update(category);
        }

        public void DeleteCategory(Guid id)
        {
            _categoryRepository.Delete(id);
        }

        public List<Category> GetAllCategories()
        {
            return _categoryRepository.GetAll();
        }
    }
}
