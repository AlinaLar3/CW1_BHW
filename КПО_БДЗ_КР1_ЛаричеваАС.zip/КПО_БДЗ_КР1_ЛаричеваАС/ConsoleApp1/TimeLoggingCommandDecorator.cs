﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Декоратор для команд, добавляющий время выполнения.
    /// </summary>
    public class TimeCommandDecorator : CommandDecorator
    {
        public TimeCommandDecorator(ICommand command) : base(command) { }

        public override void Execute()
        {
            var stopwatch = Stopwatch.StartNew();
            base.Execute();
            stopwatch.Stop();
            Console.WriteLine($"Команда выполнена за {stopwatch.ElapsedMilliseconds} ms");
        }
    }
}
