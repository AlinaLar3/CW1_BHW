﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Финансовые данные (счета, категории, операции).
    /// </summary>
    public class FinancialData : IDataElement
    {
        public List<BankAccount> BankAccounts { get; set; }
        public List<Category> Categories { get; set; }
        public List<Operation> Operations { get; set; }

        public FinancialData(List<BankAccount> bankAccounts, List<Category> categories, List<Operation> operations)
        {
            BankAccounts = bankAccounts;
            Categories = categories;
            Operations = operations;
        }

        public void Accept(IDataVisitor visitor)
        {
            visitor.Visit(this);
        }
    }
}
