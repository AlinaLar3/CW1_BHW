﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Создание банковского счёта.
    /// </summary>
    public class CreateBankAccountCommand : ICommand
    {
        private readonly IBankAccountService _bankAccountService;

        public CreateBankAccountCommand(IBankAccountService bankAccountService)
        {
            _bankAccountService = bankAccountService;
        }

        public void Execute()
        {
            Console.Write("Введите название счета: ");
            string name = Console.ReadLine();
            Console.Write("Введите начальный баланс: ");
            if (int.TryParse(Console.ReadLine(), out int balance))
            {
                BankAccount account = _bankAccountService.CreateAccount(name, balance);
                Console.WriteLine($"Создан счет: {account.Name} (ID: {account.Id}, Баланс: {account.Balance})");
            }
            else
            {
                Console.WriteLine("Неверный формат баланса.");
            }
        }
    }
}
