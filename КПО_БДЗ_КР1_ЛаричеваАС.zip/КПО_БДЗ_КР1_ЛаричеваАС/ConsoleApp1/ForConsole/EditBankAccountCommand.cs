﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Редактирование банковского счёта. 
    /// </summary>
    public class EditBankAccountCommand : ICommand
    {
        private readonly IBankAccountService _bankAccountService;

        public EditBankAccountCommand(IBankAccountService bankAccountService)
        {
            _bankAccountService = bankAccountService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите счет для редактирования:");
            List<BankAccount> accounts = _bankAccountService.GetAllAccounts();
            for (int i = 0; i < accounts.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {accounts[i].Name} (ID: {accounts[i].Id})");
            }

            if (int.TryParse(Console.ReadLine(), out int accountChoice) && accountChoice > 0 && accountChoice <= accounts.Count)
            {
                BankAccount account = accounts[accountChoice - 1];

                Console.Write("Введите новое название счета: ");
                account.Name = Console.ReadLine();

                Console.Write("Введите новый баланс счета: ");
                if (int.TryParse(Console.ReadLine(), out int newBalance))
                {
                    account.Balance = newBalance;
                    _bankAccountService.UpdateAccount(account);
                    Console.WriteLine($"Счет обновлен: {account.Name} (ID: {account.Id}, Баланс: {account.Balance})");
                }
                else
                {
                    Console.WriteLine("Неверный формат баланса. Оставлен прошлый баланс.");
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор счета.");
            }
        }
    }
}
