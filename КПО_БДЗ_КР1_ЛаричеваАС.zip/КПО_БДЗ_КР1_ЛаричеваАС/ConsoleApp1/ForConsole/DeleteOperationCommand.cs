﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Удаление финансовой операции.
    /// </summary>
    public class DeleteOperationCommand : ICommand
    {
        private readonly IOperationService _operationService;

        public DeleteOperationCommand(IOperationService operationService)
        {
            _operationService = operationService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите операцию для удаления:");
            List<Operation> operations = _operationService.GetAllOperations();
            for (int i = 0; i < operations.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {operations[i].Type} на сумму {operations[i].Amount} (ID: {operations[i].Id})");
            }

            if (int.TryParse(Console.ReadLine(), out int operationChoice) && operationChoice > 0 && operationChoice <= operations.Count)
            {
                Guid operationId = operations[operationChoice - 1].Id;
                _operationService.DeleteOperation(operationId);
                Console.WriteLine("Операция удалена.");
            }
            else
            {
                Console.WriteLine("Неверный выбор операции.");
            }
        }
    }
}
