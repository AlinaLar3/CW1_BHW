﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Вывод списка операций.
    /// </summary>
    public class ListOperationsCommand : ICommand
    {
        private readonly IOperationService _operationService;

        public ListOperationsCommand(IOperationService operationService)
        {
            _operationService = operationService;
        }

        public void Execute()
        {
            List<Operation> operations = _operationService.GetAllOperations();
            Console.WriteLine("\nСписок операций:");
            if (operations.Count == 0)
            {
                Console.WriteLine("Операций не найдено.");
            }
            else
            {
                foreach (var operation in operations)
                {
                    Console.WriteLine($"  - {operation.Type}: {operation.Amount} on {operation.Date} (ID: {operation.Id}, Счет: {operation.BankAccountId}, Категория: {operation.CategoryId}, Описание: {operation.Description})");
                }
            }
        }
    }
}
