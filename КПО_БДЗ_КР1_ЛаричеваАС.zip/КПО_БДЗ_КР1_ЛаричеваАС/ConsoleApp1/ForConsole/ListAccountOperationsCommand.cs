﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Вывод списка операций конкретного счёта.
    /// </summary>
    public class ListAccountOperationsCommand : ICommand
    {
        private readonly IOperationService _operationService;
        private readonly IBankAccountService _bankAccountService;

        public ListAccountOperationsCommand(IOperationService operationService, IBankAccountService bankAccountService)
        {
            _operationService = operationService;
            _bankAccountService = bankAccountService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите счет для просмотра операций:");
            List<BankAccount> accounts = _bankAccountService.GetAllAccounts();
            for (int i = 0; i < accounts.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {accounts[i].Name} (ID: {accounts[i].Id})");
            }

            if (int.TryParse(Console.ReadLine(), out int accountChoice) && accountChoice > 0 && accountChoice <= accounts.Count)
            {
                Guid accountId = accounts[accountChoice - 1].Id;
                List<Operation> accountOperations = _operationService.GetOperationsByAccount(accountId);

                Console.WriteLine($"\nОперации для счета {accounts[accountChoice - 1].Name}:");
                foreach (var operation in accountOperations)
                {
                    Console.WriteLine($"  - {operation.Type}: {operation.Amount} on {operation.Date} (ID: {operation.Id})");
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор счета.");
            }
        }
    }
}
