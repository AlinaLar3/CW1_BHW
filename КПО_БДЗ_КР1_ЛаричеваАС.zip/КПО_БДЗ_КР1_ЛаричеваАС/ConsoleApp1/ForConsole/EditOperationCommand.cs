﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Редактирование операции. 
    /// </summary>
    public class EditOperationCommand : ICommand
    {
        private readonly IOperationService _operationService;
        private readonly IBankAccountService _bankAccountService;
        private readonly ICategoryService _categoryService;

        public EditOperationCommand(IOperationService operationService, IBankAccountService bankAccountService, ICategoryService categoryService)
        {
            _operationService = operationService;
            _bankAccountService = bankAccountService;
            _categoryService = categoryService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите операцию для редактирования:");
            List<Operation> operations = _operationService.GetAllOperations();
            for (int i = 0; i < operations.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {operations[i].Type} на сумму {operations[i].Amount} (ID: {operations[i].Id})");
            }

            if (int.TryParse(Console.ReadLine(), out int operationChoice) && operationChoice > 0 && operationChoice <= operations.Count)
            {
                Operation operation = operations[operationChoice - 1];

                Console.WriteLine("Введите новую сумму: ");
                if (int.TryParse(Console.ReadLine(), out int newAmount))
                {
                    operation.Amount = newAmount;
                }
                else
                {
                    Console.WriteLine("Неверный формат суммы.");
                    return;
                }

                Console.WriteLine("Введите новое описание: ");
                operation.Description = Console.ReadLine();

                Console.WriteLine("Выберите новый счет:");
                List<BankAccount> accounts = _bankAccountService.GetAllAccounts();
                for (int i = 0; i < accounts.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {accounts[i].Name} (ID: {accounts[i].Id})");
                }

                if (int.TryParse(Console.ReadLine(), out int accountChoice) && accountChoice > 0 && accountChoice <= accounts.Count)
                {
                    operation.BankAccountId = accounts[accountChoice - 1].Id;
                }
                else
                {
                    Console.WriteLine("Неверный выбор счета.");
                    return;
                }

                Console.WriteLine("Выберите новую категорию:");
                List<Category> categories = _categoryService.GetAllCategories();
                for (int i = 0; i < categories.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. {categories[i].Name} (ID: {categories[i].Id})");
                }

                if (int.TryParse(Console.ReadLine(), out int categoryChoice) && categoryChoice > 0 && categoryChoice <= categories.Count)
                {
                    operation.CategoryId = categories[categoryChoice - 1].Id;
                }
                else
                {
                    Console.WriteLine("Неверный выбор категории.");
                    return;
                }

                _operationService.UpdateOperation(operation);
                Console.WriteLine($"Операция обновлена: {operation.Type} на сумму {operation.Amount} (ID: {operation.Id})");
            }
            else
            {
                Console.WriteLine("Неверный выбор операции.");
            }
        }
    }
}
