﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Редактирование команды. 
    /// </summary>
    public class EditCategoryCommand : ICommand
    {
        private readonly ICategoryService _categoryService;

        public EditCategoryCommand(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите категорию для редактирования:");
            List<Category> categories = _categoryService.GetAllCategories();
            for (int i = 0; i < categories.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {categories[i].Name} (ID: {categories[i].Id}, Тип: {categories[i].Type})");
            }

            if (int.TryParse(Console.ReadLine(), out int categoryChoice) && categoryChoice > 0 && categoryChoice <= categories.Count)
            {
                Category category = categories[categoryChoice - 1];

                Console.Write("Введите новое название категории: ");
                category.Name = Console.ReadLine();

                Console.WriteLine("Выберите новый тип категории (1 - доход, 2 - расход): ");
                if (int.TryParse(Console.ReadLine(), out int typeChoice))
                {
                    category.Type = typeChoice == 1 ? CategoryType.Income : CategoryType.Expense;
                    _categoryService.UpdateCategory(category);
                    Console.WriteLine($"Категория обновлена: {category.Name} (ID: {category.Id}, Тип: {category.Type})");
                }
                else
                {
                    Console.WriteLine("Неверный формат типа категории. Оставлен прошлый тип.");
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор категории.");
            }
        }
    }
}
