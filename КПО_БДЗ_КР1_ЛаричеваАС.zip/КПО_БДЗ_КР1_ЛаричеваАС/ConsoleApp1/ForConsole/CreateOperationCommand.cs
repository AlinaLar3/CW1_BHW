﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Создание финансовой операции.
    /// </summary>
    public class CreateOperationCommand : ICommand
    {
        private readonly IOperationService _operationService;
        private readonly IBankAccountService _bankAccountService;
        private readonly ICategoryService _categoryService;

        public CreateOperationCommand(IOperationService operationService, IBankAccountService bankAccountService, ICategoryService categoryService)
        {
            _operationService = operationService;
            _bankAccountService = bankAccountService;
            _categoryService = categoryService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите счет:");
            List<BankAccount> accounts = _bankAccountService.GetAllAccounts();
            for (int i = 0; i < accounts.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {accounts[i].Name} (ID: {accounts[i].Id})");
            }
            if (int.TryParse(Console.ReadLine(), out int accountChoice) && accountChoice > 0 && accountChoice <= accounts.Count)
            {
                Guid bankAccountId = accounts[accountChoice - 1].Id;

                Console.Write("Введите сумму: ");
                if (int.TryParse(Console.ReadLine(), out int amount))
                {
                    Console.WriteLine("Выберите категорию:");
                    List<Category> categories = _categoryService.GetAllCategories();
                    for (int i = 0; i < categories.Count; i++)
                    {
                        Console.WriteLine($"{i + 1}. {categories[i].Name} (ID: {categories[i].Id})");
                    }
                    if (int.TryParse(Console.ReadLine(), out int categoryChoice) && categoryChoice > 0 && categoryChoice <= categories.Count)
                    {
                        Guid categoryId = categories[categoryChoice - 1].Id;

                        Console.Write("Введите описание: ");
                        string description = Console.ReadLine();
                        Category category_curr = new Category();
                        foreach (var category in categories)
                        {
                            if (category.Id == categoryId)
                            {
                                category_curr = category;
                            }
                        }
                        Operation operation = _operationService.CreateOperation(category_curr.Type, bankAccountId, amount, DateTime.Now, categoryId, description);
                        Console.WriteLine($"Создана операция: {operation.Type} на сумму {operation.Amount} (ID: {operation.Id})");
                    }
                    else
                    {
                        Console.WriteLine("Неверный выбор категории.");
                    }
                }
                else
                {
                    Console.WriteLine("Неверный формат суммы.");
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор счета.");
            }

        }
    }
}
