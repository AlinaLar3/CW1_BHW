﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Экспорт данных.
    /// </summary>
    public class ExportDataCommand : ICommand
    {
        private readonly IBankAccountService _bankAccountService;
        private readonly ICategoryService _categoryService;
        private readonly IOperationService _operationService;
        private readonly string _fileType;

        public ExportDataCommand(IBankAccountService bankAccountService, ICategoryService categoryService, IOperationService operationService, string fileType)
        {
            _bankAccountService = bankAccountService;
            _categoryService = categoryService;
            _operationService = operationService;
            _fileType = fileType;
        }

        public void Execute()
        {
            Console.Write("Введите полный путь файла для экспорта: ");
            string fileName = Console.ReadLine();

            FinancialData dataToExport = new FinancialData(_bankAccountService.GetAllAccounts(), _categoryService.GetAllCategories(), _operationService.GetAllOperations());
            IDataVisitor visitor = null;

            switch (_fileType.ToLower())
            {
                case "json":
                    visitor = new JsonDataVisitor(fileName);
                    break;
                case "csv":
                    visitor = new CsvDataVisitor(fileName);
                    break;
                default:
                    Console.WriteLine("Неподдерживаемый формат файла.");
                    return;
            }

            dataToExport.Accept(visitor);
            Console.WriteLine("Данные экспортированы.");
        }
    }
}
