﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Удаление категории. Удаляются связанные с ней операции.
    /// </summary>
    public class DeleteCategoryCommand : ICommand
    {
        private readonly ICategoryService _categoryService;
        private readonly IOperationService _operationService;

        public DeleteCategoryCommand(ICategoryService categoryService, IOperationService operationService)
        {
            _categoryService = categoryService;
            _operationService = operationService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите категорию для удаления:");
            List<Category> categories = _categoryService.GetAllCategories();
            for (int i = 0; i < categories.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {categories[i].Name} (ID: {categories[i].Id}, Тип: {categories[i].Type})");
            }

            if (int.TryParse(Console.ReadLine(), out int categoryChoice) && categoryChoice > 0 && categoryChoice <= categories.Count)
            {
                Guid categoryId = categories[categoryChoice - 1].Id;
                _categoryService.DeleteCategory(categoryId);
                Console.WriteLine("Категория удалена.");
                List<Operation> operations = _operationService.GetAllOperations();
                for (int i = operations.Count() - 1; i > -1; i--)
                {
                    if (operations[i].CategoryId == categoryId)
                    {
                        _operationService.DeleteOperation(operations[i].Id);
                    }
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор категории.");
            }
        }
    }
}
