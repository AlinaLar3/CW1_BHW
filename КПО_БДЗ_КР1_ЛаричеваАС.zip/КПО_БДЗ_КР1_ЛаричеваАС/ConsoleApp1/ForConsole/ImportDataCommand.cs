﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Импорт данных.
    /// </summary>
    public class ImportDataCommand : ICommand
    {
        private readonly IBankAccountService _bankAccountService;
        private readonly ICategoryService _categoryService;
        private readonly IOperationService _operationService;
        private readonly string _fileType;

        public ImportDataCommand(IBankAccountService bankAccountService, ICategoryService categoryService, IOperationService operationService, string fileType)
        {
            _bankAccountService = bankAccountService;
            _categoryService = categoryService;
            _operationService = operationService;
            _fileType = fileType;
        }

        public void Execute()
        {
            Console.Write("Введите полный путь файла для импорта: ");
            string fileName = Console.ReadLine();

            DataImporter importer = null;

            switch (_fileType.ToLower())
            {
                case "json":
                    importer = new JsonDataImporter();
                    break;
                case "csv":
                    importer = new CsvDataImporter();
                    break;
                default:
                    Console.WriteLine("Неподдерживаемый формат файла.");
                    return;
            }

            importer.ImportData(fileName, _bankAccountService, _categoryService, _operationService);
            Console.WriteLine("Данные импортированы.");
        }
    }
}
