﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Удаление банковского счёта. Удаляются связанные с ним операции.
    /// </summary>
    public class DeleteBankAccountCommand : ICommand
    {
        private readonly IBankAccountService _bankAccountService;
        private readonly IOperationService _operationService;

        public DeleteBankAccountCommand(IBankAccountService bankAccountService, IOperationService operationService)
        {
            _bankAccountService = bankAccountService;
            _operationService = operationService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите счет для удаления:");
            List<BankAccount> accounts = _bankAccountService.GetAllAccounts();
            for (int i = 0; i < accounts.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {accounts[i].Name} (ID: {accounts[i].Id})");
            }

            if (int.TryParse(Console.ReadLine(), out int accountChoice) && accountChoice > 0 && accountChoice <= accounts.Count)
            {
                Guid accountId = accounts[accountChoice - 1].Id;
                _bankAccountService.DeleteAccount(accountId);
                Console.WriteLine("Счет удален.");
                List<Operation> operations = _operationService.GetAllOperations();
                for (int i = operations.Count() - 1; i > -1; i--)
                {
                    if (operations[i].BankAccountId == accountId)
                    {
                        _operationService.DeleteOperation(operations[i].Id);
                    }
                }
            }
            else
            {
                Console.WriteLine("Неверный выбор счета.");
            }
        }
    }
}
