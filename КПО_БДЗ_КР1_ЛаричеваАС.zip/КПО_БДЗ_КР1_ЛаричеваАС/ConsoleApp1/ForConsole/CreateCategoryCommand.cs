﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Создание категории.
    /// </summary>
    public class CreateCategoryCommand : ICommand
    {
        private readonly ICategoryService _categoryService;

        public CreateCategoryCommand(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        public void Execute()
        {
            Console.WriteLine("Выберите тип категории (1 - доход, 2 - расход): ");
            if (int.TryParse(Console.ReadLine(), out int typeChoice))
            {
                CategoryType type = typeChoice == 1 ? CategoryType.Income : CategoryType.Expense;
                Console.Write("Введите название категории: ");
                string name = Console.ReadLine();
                Category category = _categoryService.CreateCategory(type, name);
                Console.WriteLine($"Создана категория: {category.Name} (ID: {category.Id}, Тип: {category.Type})");
            }
            else
            {
                Console.WriteLine("Неверный формат типа категории.");
            }
        }
    }
}
