﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Вывод списка категорий.
    /// </summary>
    public class ListCategoriesCommand : ICommand
    {
        private readonly ICategoryService _categoryService;

        public ListCategoriesCommand(ICategoryService categoryService)
        {
            _categoryService = categoryService;
        }

        public void Execute()
        {
            List<Category> categories = _categoryService.GetAllCategories();
            Console.WriteLine("\nСписок категорий:");
            if (categories.Count == 0)
            {
                Console.WriteLine("Категорий не найдено.");
            }
            else
            {
                foreach (var category in categories)
                {
                    Console.WriteLine($"  - {category.Name} (ID: {category.Id}, Тип: {category.Type})");
                }
            }
        }
    }
}
