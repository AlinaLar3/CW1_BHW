﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS.ForConsole
{
    /// <summary>
    /// Реализация команды: Вывод списка банковских счетов.
    /// </summary>
    public class ListBankAccountsCommand : ICommand
    {
        private readonly IBankAccountService _bankAccountService;

        public ListBankAccountsCommand(IBankAccountService bankAccountService)
        {
            _bankAccountService = bankAccountService;
        }

        public void Execute()
        {
            List<BankAccount> accounts = _bankAccountService.GetAllAccounts();
            Console.WriteLine("\nСписок счетов:");
            if (accounts.Count == 0)
            {
                Console.WriteLine("Счетов не найдено.");
            }
            else
            {
                foreach (var account in accounts)
                {
                    Console.WriteLine($"  - {account.Name} (ID: {account.Id}, Баланс: {account.Balance})");
                }
            }
        }
    }
}
