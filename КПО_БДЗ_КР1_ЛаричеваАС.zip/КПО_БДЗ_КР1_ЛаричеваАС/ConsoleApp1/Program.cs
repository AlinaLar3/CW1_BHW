﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json;
using System.Text.Json.Serialization;
using CW1_LarichevaAS;
using CW1_LarichevaAS.ForConsole;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Точка входа и настройки DI-контейнера.
    /// </summary>
    public class Program
    {
        /// <summary>
        ///  Настройки DI-контейнера.
        /// </summary>
        /// <returns></returns>
        private static IServiceProvider ConfigureServices()
        {
            var services = new ServiceCollection();

            services.AddSingleton<IRepositoryFactory, InMemoryRepositoryFactory>();
            services.AddSingleton(provider => provider.GetService<IRepositoryFactory>().CreateRepository<BankAccount>());
            services.AddSingleton(provider => provider.GetService<IRepositoryFactory>().CreateRepository<Category>());
            services.AddSingleton(provider => provider.GetService<IRepositoryFactory>().CreateRepository<Operation>());

            services.AddSingleton<IBankAccountService, BankAccountService>();
            services.AddSingleton<ICategoryService, CategoryService>();
            services.AddSingleton<IOperationService, OperationService>();

            return services.BuildServiceProvider();
        }

        public static void Main(string[] args)
        {
            var serviceProvider = ConfigureServices();
            // Получение сервисов из контейнера.
            var bankAccountService = serviceProvider.GetService<IBankAccountService>();
            var categoryService = serviceProvider.GetService<ICategoryService>();
            var operationService = serviceProvider.GetService<IOperationService>();

            while (true)
            {
                Console.WriteLine("\nВыберите действие:");
                Console.WriteLine("1. Создать счет");
                Console.WriteLine("2. Создать категорию");
                Console.WriteLine("3. Создать операцию");
                Console.WriteLine("4. Редактировать счет");
                Console.WriteLine("5. Редактировать категорию");
                Console.WriteLine("6. Редактировать операцию");
                Console.WriteLine("7. Удалить счет");
                Console.WriteLine("8. Удалить категорию");
                Console.WriteLine("9. Удалить операцию");
                Console.WriteLine("10. Экспорт данных в JSON");
                Console.WriteLine("11. Экспорт данных в CSV");
                Console.WriteLine("12. Импорт данных из JSON");
                Console.WriteLine("13. Импорт данных из CSV");
                Console.WriteLine("14. Список операций по счету");
                Console.WriteLine("15. Вывод списка счетов");
                Console.WriteLine("16. Вывод списка операций");
                Console.WriteLine("17. Вывод списка категорий");
                Console.WriteLine("0. Выход");

                Console.Write("Ваш выбор: ");
                string choice = Console.ReadLine();

                ICommand command = null;

                try
                {
                    switch (choice)
                    {
                        case "1":
                            command = new CreateBankAccountCommand(bankAccountService);
                            break;
                        case "2":
                            command = new CreateCategoryCommand(categoryService);
                            break;
                        case "3":
                            command = new CreateOperationCommand(operationService, bankAccountService, categoryService);
                            break;
                        case "4":
                            command = new EditBankAccountCommand(bankAccountService);
                            break;
                        case "5":
                            command = new EditCategoryCommand(categoryService);
                            break;
                        case "6":
                            command = new EditOperationCommand(operationService, bankAccountService, categoryService);
                            break;
                        case "7":
                            command = new DeleteBankAccountCommand(bankAccountService, operationService);
                            break;
                        case "8":
                            command = new DeleteCategoryCommand(categoryService, operationService);
                            break;
                        case "9":
                            command = new DeleteOperationCommand(operationService);
                            break;
                        case "10":
                            command = new ExportDataCommand(bankAccountService, categoryService, operationService, "json");
                            break;
                        case "11":
                            command = new ExportDataCommand(bankAccountService, categoryService, operationService, "csv");
                            break;
                        case "12":
                            command = new ImportDataCommand(bankAccountService, categoryService, operationService, "json");
                            break;
                        case "13":
                            command = new ImportDataCommand(bankAccountService, categoryService, operationService, "csv");
                            break;
                        case "14":
                            command = new ListAccountOperationsCommand(operationService, bankAccountService);
                            break;
                        case "15":
                            command = new ListBankAccountsCommand(bankAccountService);
                            break;
                        case "16":
                            command = new ListOperationsCommand(operationService);
                            break;
                        case "17":
                            command = new ListCategoriesCommand(categoryService);
                            break;
                        case "0":
                            Console.WriteLine("Выход из программы.");
                            return;
                        default:
                            Console.WriteLine("Неверный выбор. Попробуйте снова.");
                            break;
                    }
                    // Оборачиваем команду декоратором для измерения времени.
                    if (command != null)
                    {
                        Console.Clear();
                        ICommand timedCommand = new TimeCommandDecorator(command);
                        timedCommand.Execute();
                    }

                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка: {ex.Message}");
                }
            }
        }
    }
}