﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Импорт данных в JSON.
    /// </summary>
    public class JsonDataImporter : DataImporter
    {
        protected override string ReadData(string filePath)
        {
            return System.IO.File.ReadAllText(filePath);
        }

        protected override FinancialData ParseData(string data)
        {
            try
            {
                var options = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                return JsonSerializer.Deserialize<FinancialData>(data, options);
            }
            catch (JsonException ex)
            {
                Console.WriteLine($"JSON Parsing Error: {ex.Message}");
                return null;
            }
        }
    }
}
