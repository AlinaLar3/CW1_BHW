﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CW1_LarichevaAS
{
    /// <summary>
    /// Перечисление для типа категории.
    /// </summary>
    public enum CategoryType
    {
        Income,
        Expense
    }
}
